import { AuthFunctions } from "../components/AuthFunction";

export default function x() {
    return (
      <AuthFunctions></AuthFunctions>
    );
}
